#Login page locators
login_logo_xpath= "//*[@Class='orangehrm-login-logo']"
username_xpath= "//input[@name='username']"
password_xpath= "//input[@name='password']"
login_button_xpath= "//button[@type='submit']"

#Home page locators




#logout page locators
dropdown_xpath= "//*[@class='oxd-userdropdown-tab']"
logout_btn_xpath= "//*[@class='oxd-userdropdown-link']"