insert into person values(102,'Ram','7859562355');
insert into person values(103,'Vjay','3625896555');
insert into person values(104,'Viky','9563256822');
insert into person values(105,'Rahul','9158565604');