import random
lt=[1,2,5,7]
print(lt)