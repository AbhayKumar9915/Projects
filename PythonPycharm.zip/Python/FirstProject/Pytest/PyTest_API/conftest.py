import pytest


@pytest.fixture
def supply_url():
    return "https://reqres.in/api"
